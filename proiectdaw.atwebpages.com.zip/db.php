<?php
$host = 'fdb1031.runhosting.com';
$user = '4396284_nume';
$password = 'Georgian4';
$database = '4396284_nume';
$port = 3306;

// Creează conexiunea
$con = mysqli_connect($host, $user, $password, $database, $port);

// Verifică conexiunea
if (!$con) {
    die("Conexiunea la baza de date a eșuat: " . mysqli_connect_error());
}
?>
