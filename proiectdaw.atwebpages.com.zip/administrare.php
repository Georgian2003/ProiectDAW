<?php
include("db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adauga_sectie'])) {
    $nume_sectie = $_POST['denumire'];
    $cod_sectie = $_POST['cod_sectie'];
    $cod_facultate = 1;

    // Verificare format cod_sectie și denumire
    if (ctype_digit($cod_sectie) && ctype_alpha($nume_sectie)) {
        // Continuă cu operația de inserare în baza de date
        $query_adauga_sectie = "INSERT INTO sectie (cod_sectie, denumire, cod_facultate) VALUES ('$cod_sectie', '$nume_sectie', '$cod_facultate')";
        mysqli_query($con, $query_adauga_sectie);
    } else {
        // Afisează mesaj de eroare sau redirectează către o pagină de eroare
        echo "Format incorect pentru cod_sectie sau denumire. Codul sectiei trebuie să conțină doar cifre, iar denumirea să conțină doar litere.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sterge_sectie'])) {
    $id_sectie_sters = $_POST['id_sectie_sters'];

    if (!empty($id_sectie_sters)) {
        $query_sterge_sectie = "DELETE FROM sectie WHERE cod_sectie = $id_sectie_sters";
        mysqli_query($con, $query_sterge_sectie);
    }
}

$query_sectii = "SELECT * FROM sectie";
$result_sectii = mysqli_query($con, $query_sectii);
?>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adauga_serie'])) {
    $nume_serie = $_POST['denumire_serie'];
    $cod_serie = $_POST['cod_serie'];
    $cod_sectie_serie = $_POST['cod_sectie_serie'];

    // Verificare format cod_serie și denumire_serie
    if (is_numeric($cod_serie) && is_numeric($cod_sectie_serie)) {
        // Continuă cu operația de inserare în baza de date
        $query_adauga_serie = "INSERT INTO serie (cod_serie, denumire, cod_sectie) VALUES ('$cod_serie', '$nume_serie', '$cod_sectie_serie')";
        mysqli_query($con, $query_adauga_serie);
    } else {
        // Afisează mesaj de eroare sau redirectează către o pagină de eroare
        echo "Format incorect pentru cod_serie, denumire_serie sau cod_sectie_serie. Codul seriei și codul sectiei trebuie să conțină doar cifre.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sterge_serie'])) {
    $id_serie_sters = $_POST['id_serie_sters'];

    if (!empty($id_serie_sters)) {
        $query_sterge_serie = "DELETE FROM serie WHERE cod_serie = $id_serie_sters";
        mysqli_query($con, $query_sterge_serie);
    }
}

$query_seriile = "SELECT * FROM serie";
$result_seriile = mysqli_query($con, $query_seriile);
?>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adauga_materie'])) {
    $denumire_materie = $_POST['denumire_materie'];
    $cod_materie = $_POST['cod_materie'];
    $numar_de_ore = $_POST['numar_de_ore'];

    // Verificare format cod_materie și denumire_materie
    if (is_numeric($cod_materie) && ctype_alnum($denumire_materie) && is_numeric($numar_de_ore)) {
        // Continuă cu operația de inserare în baza de date
        $query_adauga_materie = "INSERT INTO materie (cod_materie, denumire, numar_de_ore) VALUES ('$cod_materie', '$denumire_materie', '$numar_de_ore')";
        mysqli_query($con, $query_adauga_materie);
    } else {
        // Afisează mesaj de eroare sau redirectează către o pagină de eroare
        echo "Format incorect pentru cod_materie, denumire_materie sau numar_de_ore. Codul materiei și numărul de ore trebuie să conțină doar cifre, iar denumirea să conțină doar litere și cifre.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sterge_materie'])) {
    $id_materie_sters = $_POST['id_materie_sters'];

    if (!empty($id_materie_sters)) {
        $query_sterge_materie = "DELETE FROM materie WHERE cod_materie = $id_materie_sters";
        mysqli_query($con, $query_sterge_materie);
    }
}

$query_materii = "SELECT * FROM materie";
$result_materii = mysqli_query($con, $query_materii);
?>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adauga_examen'])) {
    $cod_examen = $_POST['cod_examen'];
    $nota_minima = $_POST['nota_minima'];
    $mod_de_sustinere = $_POST['mod_de_sustinere'];
    $cod_materie_examen = $_POST['cod_materie_examen'];

    // Verificare format cod_examen, nota_minima și mod_de_sustinere
    if (is_numeric($cod_examen) && is_numeric($nota_minima) && $nota_minima >= 1 && $nota_minima <= 10 && ctype_alpha($mod_de_sustinere) && is_numeric($cod_materie_examen)) {
        // Continuă cu operația de inserare în baza de date
        $query_adauga_examen = "INSERT INTO examen (cod_examen, nota_minima, mod_de_sustinere, cod_materie) VALUES ('$cod_examen', '$nota_minima', '$mod_de_sustinere', '$cod_materie_examen')";
        mysqli_query($con, $query_adauga_examen);
    } else {
        // Afisează mesaj de eroare sau redirectează către o pagină de eroare
        echo "Format incorect pentru cod_examen, nota_minima, mod_de_sustinere sau cod_materie_examen. Codul examenului, nota minimă trebuie să fie un număr între 1 și 10, modul de susținere să conțină doar litere, iar codul materiei să conțină doar cifre.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sterge_examen'])) {
    $id_examen_sters = $_POST['id_examen_sters'];

    if (!empty($id_examen_sters)) {
        $query_sterge_examen = "DELETE FROM examen WHERE cod_examen = $id_examen_sters";
        mysqli_query($con, $query_sterge_examen);
    }
}

$query_examene = "SELECT * FROM examen";
$result_examene = mysqli_query($con, $query_examene);
?>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adauga_promoveaza'])) {
    $cod_promoveaza = $_POST['cod_promoveaza'];
    $cod_student_promoveaza = $_POST['cod_student_promoveaza'];
    $cod_examen_promoveaza = $_POST['cod_examen_promoveaza'];
    $nota_promoveaza = $_POST['nota_promoveaza'];

    // Verificare format cod_promoveaza, cod_student_promoveaza, cod_examen_promoveaza și nota_promoveaza
    if (is_numeric($cod_promoveaza) && is_numeric($cod_student_promoveaza) && is_numeric($cod_examen_promoveaza) && is_numeric($nota_promoveaza) && $nota_promoveaza >= 1 && $nota_promoveaza <= 10) {
        // Continuă cu operația de inserare în baza de date
        $query_adauga_promoveaza = "INSERT INTO promoveaza (cod_promoveaza, cod_student, cod_examen, nota) VALUES ('$cod_promoveaza', '$cod_student_promoveaza', '$cod_examen_promoveaza', '$nota_promoveaza')";
        mysqli_query($con, $query_adauga_promoveaza);
    } else {
        // Afisează mesaj de eroare sau redirectează către o pagină de eroare
        echo "Format incorect pentru cod_promoveaza, cod_student_promoveaza, cod_examen_promoveaza sau nota_promoveaza. Codul de promovare, codul studentului și codul examenului trebuie să conțină doar cifre, iar nota să fie un număr între 1 și 10.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sterge_promoveaza'])) {
    $id_promoveaza_sters = $_POST['id_promoveaza_sters'];

    if (!empty($id_promoveaza_sters)) {
        $query_sterge_promoveaza = "DELETE FROM promoveaza WHERE cod_promoveaza = $id_promoveaza_sters";
        mysqli_query($con, $query_sterge_promoveaza);
    }
}

$query_promoveaza = "SELECT * FROM promoveaza";
$result_promoveaza = mysqli_query($con, $query_promoveaza);
?>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adauga_sala'])) {
    $cod_sala = $_POST['cod_sala'];
    $denumire_sala = $_POST['denumire_sala'];
    $locatie_sala = $_POST['locatie_sala'];
    $capacitate_sala = $_POST['capacitate_sala'];

    // Verificare format cod_sala, denumire_sala, locatie_sala și capacitate_sala
    if (is_numeric($cod_sala) && ctype_alpha($denumire_sala) && is_numeric($capacitate_sala)) {
        // Continuă cu operația de inserare în baza de date
        $query_adauga_sala = "INSERT INTO sala (cod_sala, denumire, locatie, capacitate) VALUES ('$cod_sala', '$denumire_sala', '$locatie_sala', '$capacitate_sala')";
        mysqli_query($con, $query_adauga_sala);
    } else {
        // Afisează mesaj de eroare sau redirectează către o pagină de eroare
        echo "Format incorect pentru cod_sala, denumire_sala sau capacitate_sala. Codul sălii și capacitatea trebuie să conțină doar cifre, iar denumirea să conțină doar litere.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sterge_sala'])) {
    $id_sala_stearsa = $_POST['id_sala_stearsa'];

    if (!empty($id_sala_stearsa)) {
        $query_sterge_sala = "DELETE FROM sala WHERE cod_sala = $id_sala_stearsa";
        mysqli_query($con, $query_sterge_sala);
    }
}

$query_sali = "SELECT * FROM sala";
$result_sali = mysqli_query($con, $query_sali);
?>
<style>
        body {
    margin: 0;
    padding: 0;
    font-family: 'Oswald', sans-serif;
    background-image: url('poza4.jpg'); /* Adaugă imaginea de fundal */
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
  }
  body::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
    background-image: url('poza4.jpg');
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    opacity: 0.6;
  }
  
  .container {
    text-align: center;
    background-color: #ffd900b0;
    padding: 20px;
    margin: auto; /* Adaugă această linie pentru a centra containerul */
    margin-top: 100px; /* Ajustează distanța de la partea de sus a paginii */
  }
  
  ul {
    list-style: none;
    margin: 0;
    padding: 0;
  }
  
  a {
    text-decoration: none;
    color: #D2B48C;
  }
  
  /* Header Styles */
  header {
    background-color: transparent;
    padding: 20px;
    text-align: center;
  }
  
  h1 {
    color: #DEB887;
    font-family: 'Great Vibes', cursive;
    font-size: 36px;
    margin: 0;
  }
  
  /* Navigation Styles */
  nav {
    text-align: center;
  }
  
  nav ul {
    display: flex;
    justify-content: center;
  }
  
  nav li {
    margin: 0 15px;
    position: relative;
  }
  
  nav a {
    font-size: 18px;
    text-transform: uppercase;
    color: #D2B48C;
    padding: 15px;
    display: inline-block;
  }
  
  /* Dropdown Styles */
  nav ul ul {
    display: none;
    position: absolute;
    background-color: #36454F;
    border: 1px solid #D2B48C;
    padding: 10px;
  }
  
  nav li:hover > ul {
    display: grid;
  }
  
  nav ul ul li {
    display: block;
    color: #D2B48C;
  }
  
  /* Form Container Styles */
 .form-container {
  margin: 20px;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.form-container h2 {
  color: #36454F;
}

.form-container label {
  display: block;
  margin-top: 10px;
  color: #36454F;
}

.form-container input {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
  margin-bottom: 10px;
  box-sizing: border-box;
}

.form-container button {
  background-color: #36454F;
  color: #fff;
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
  
  label {
    font-weight: bold;
    width: 120px;
    margin-left: 10px;
  }
  
  input,
  textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s ease-in-out;
  }
  
  input:focus,
  textarea:focus {
    border-color: #D2B48C;
  }
  
  .button-container {
    display: flex;
    flex-direction: column; /* Modificare pentru a aranja butoanele pe o coloană */
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  
  button {
    width: 300px; /* Ajustează lățimea butoanelor după preferințe */
    height: 70px; /* Ajustează înălțimea butoanelor după preferințe */
    margin: 10px;
    background-color: #D2B48C;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  
  button:hover {
    background-color: #A88F61;
  }
  
  /* Buton de logout */
  a.logout-button {
    display: block;
    width: 150px; /* Ajustează dimensiunea dorită pentru butonul de logout */
    padding: 15px; /* Ajustează dimensiunea dorită pentru butonul de logout */
    background-color: #D2B48C;
    color: #fff;
    border: none;
    border-radius: 5px;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  
  a.logout-button:hover {
    background-color: #A88F61;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #36454F;
    border: 1px solid #D2B48C;
    padding: 10px;
    z-index: 1;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
  .dropdown-content a {
    color: #D2B48C;
  }
  
  .dropdown-content a:hover {
    background-color: #A88F61;
  }
  /* Tabel Styles */
  table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 20px;
  }
  
  th, td {
    border: 1px solid #D2B48C;
    padding: 8px;
    text-align: left;
    font-size: 16px;
  }
  
  th {
    background-color: #36454F;
    color: #fff;
  }
  
  td {
    background-color: #D2B48C; /* Culoarea de fundal pentru celulele din tabel */
    color: #36454F; /* Culoarea textului pentru contrast */
  }
  
  /* Hover Effect on Rows */
  tr:hover {
    background-color: #D2B48C;
    color: #fff;
  }
  
  /* Button Styles within Table */
  table form {
    display: flex;
    justify-content: space-around;
    align-items: center;
  }
  
  table form input[type="submit"] {
    width: auto;
    background-color: #A88F61;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    padding: 5px 10px;
  }
  
  table form input[type="submit"]:hover {
    background-color: #856C4E;
  }
  #formularAdaugare {
    margin-top: 20px;
    padding: 15px;
    border: 1px solid #4682B4;
    border-radius: 5px;
    background-color: #e6f7ec; /* Culoarea de fundal a formularului */
}

#formularAdaugare input {
    margin-bottom: 10px;
    padding: 8px;
    width: 200px;
    box-sizing: border-box;
}

#formularAdaugare input[type="submit"] {
    background-color: #4caf50; /* Culoarea butonului */
    color: white;
    cursor: pointer;
}

#formularAdaugare input[type="submit"]:hover {
    background-color: #45a049; /* Culoarea butonului la hover */
}
  
        </style>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8">
    <title>Dashboard - Admin Sectii</title>
    <script>
        function toggleTable(id) {
            var table = document.getElementById(id);
            table.style.display = (table.style.display === 'none') ? '' : 'none';
        }
    </script>
</head>
<body>
<header>
<nav id="navigation">
        <ul>
            <li><a href="index_admin.php">Acasă</a></li>
            <li class="dropdown">
                <a href="admin_profesori.php" onclick="toggleDropdown()">Profesori</a>
                <div class="dropdown-content" id="profDropdown">
                    <a href="contracte_profesori.php">Contracte</a>
                    <a href="cursuri_profesori.php">Cursuri</a>
                </div>
            </li>
            <li><a href="admin_studenti.php">Studenți</a></li>
            <li><a href="administrare.php">Administrare</a></li>
        </ul>
    </nav>
</header>
<div class="button-container">
<div class="form">
    <button onclick="toggleTable('sectieOptions')">Administrare Secții</button>
    <div id="sectieOptions" style="display:none;">
        <button onclick="toggleTable('sectiiTable')">Afișează Secții</button>
        <button onclick="toggleTable('sectieForm')">Adaugă Secție</button>
    </div>

    <div id="sectieForm" style="display:none;">
        <h2>Adaugă Secție</h2>
        <form method="post" action="">
            Cod Secție: <input type="text" name="cod_sectie" required>
            Nume Secție: <input type="text" name="denumire" required>
            <input type="submit" name="adauga_sectie" value="Adaugă Secție">
        </form>
    </div>

    <table border="1" id="sectiiTable" style="display:none;">
        <tr>
            <th>Cod Secție</th>
            <th>Nume Secție</th>
            <th>Șterge</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result_sectii)) {
            echo "<tr>";
            echo "<td>" . $row['cod_sectie'] . "</td>";
            echo "<td>" . $row['denumire'] . "</td>";
            echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_sectie_sters' value='" . $row['cod_sectie'] . "'>
                        <input type='submit' name='sterge_sectie' value='Șterge'>
                    </form>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>
</div>
<div class="form">
    <button onclick="toggleTable('serieOptions')">Administrare Serii</button>
    <div id="serieOptions" style="display:none;">
        <button onclick="toggleTable('seriiTable')">Afișează Serii</button>
        <button onclick="toggleTable('serieForm')">Adaugă Serie</button>
    </div>

    <div id="serieForm" style="display:none;">
        <h2>Adaugă Serie</h2>
        <form method="post" action="">
            Cod Serie: <input type="number" name="cod_serie" required>
            Nume Serie: <input type="text" name="denumire_serie" required>
            Cod Sectie: <input type="number" name="cod_sectie_serie" required>
            <input type="submit" name="adauga_serie" value="Adaugă Serie">
        </form>
    </div>

    <table border="1" id="seriiTable" style="display:none;">
        <tr>
            <th>Cod Serie</th>
            <th>Nume Serie</th>
            <th>Cod Sectie</th>
            <th>Șterge</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result_seriile)) {
            echo "<tr>";
            echo "<td>" . $row['cod_serie'] . "</td>";
            echo "<td>" . $row['denumire'] . "</td>";
            echo "<td>" . $row['cod_sectie'] . "</td>";
            echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_serie_sters' value='" . $row['cod_serie'] . "'>
                        <input type='submit' name='sterge_serie' value='Șterge'>
                    </form>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>
</div>
<div class="form">
    <button onclick="toggleTable('materieOptions')">Administrare Materii</button>
    <div id="materieOptions" style="display:none;">
        <button onclick="toggleTable('materiiTable')">Afișează Materii</button>
        <button onclick="toggleTable('materieForm')">Adaugă Materie</button>
    </div>

    <div id="materieForm" style="display:none;">
        <h2>Adaugă Materie</h2>
        <form method="post" action="">
            Cod Materie: <input type="number" name="cod_materie" required>
            Nume Materie: <input type="text" name="denumire_materie" required>
            Număr de Ore: <input type="number" name="numar_de_ore" required>
            <input type="submit" name="adauga_materie" value="Adaugă Materie">
        </form>
    </div>

    <table border="1" id="materiiTable" style="display:none;">
        <tr>
            <th>Cod Materie</th>
            <th>Nume Materie</th>
            <th>Număr de Ore</th>
            <th>Șterge</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result_materii)) {
            echo "<tr>";
            echo "<td>" . $row['cod_materie'] . "</td>";
            echo "<td>" . $row['denumire'] . "</td>";
            echo "<td>" . $row['numar_de_ore'] . "</td>";
            echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_materie_sters' value='" . $row['cod_materie'] . "'>
                        <input type='submit' name='sterge_materie' value='Șterge'>
                    </form>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>
</div>
<div class="form">
    <button onclick="toggleTable('examenOptions')">Administrare Examene</button>
    <div id="examenOptions" style="display:none;">
        <button onclick="toggleTable('exameneTable')">Afișează Examene</button>
        <button onclick="toggleTable('examenForm')">Adaugă Examen</button>
    </div>

    <div id="examenForm" style="display:none;">
        <h2>Adaugă Examen</h2>
        <form method="post" action="">
            Cod Examen: <input type="number" name="cod_examen" required>
            Nota Minima: <input type="number" name="nota_minima" required>
            Mod de Sustinere: <input type="text" name="mod_de_sustinere" required>
            Cod Materie: <input type="number" name="cod_materie_examen" required>
            <input type="submit" name="adauga_examen" value="Adaugă Examen">
        </form>
    </div>

    <table border="1" id="exameneTable" style="display:none;">
        <tr>
            <th>Cod Examen</th>
            <th>Nota Minima</th>
            <th>Mod de Sustinere</th>
            <th>Cod Materie</th>
            <th>Șterge</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result_examene)) {
            echo "<tr>";
            echo "<td>" . $row['cod_examen'] . "</td>";
            echo "<td>" . $row['nota_minima'] . "</td>";
            echo "<td>" . $row['mod_de_sustinere'] . "</td>";
            echo "<td>" . $row['cod_materie'] . "</td>";
            echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_examen_sters' value='" . $row['cod_examen'] . "'>
                        <input type='submit' name='sterge_examen' value='Șterge'>
                    </form>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>
</div>
<div class="form">
    <button onclick="toggleTable('promoveazaOptions')">Administrare Promoveaza</button>
    <div id="promoveazaOptions" style="display:none;">
        <button onclick="toggleTable('promoveazaTable')">Afișează Promoveaza</button>
        <button onclick="toggleTable('promoveazaForm')">Adaugă Promoveaza</button>
    </div>

    <div id="promoveazaForm" style="display:none;">
        <h2>Adaugă Promoveaza</h2>
        <form method="post" action="">
            Cod Promoveaza: <input type="number" name="cod_promoveaza" required>
            Cod Student: <input type="number" name="cod_student_promoveaza" required>
            Cod Examen: <input type="number" name="cod_examen_promoveaza" required>
            Nota: <input type="number" name="nota_promoveaza" required>
            <input type="submit" name="adauga_promoveaza" value="Adaugă Promoveaza">
        </form>
    </div>

    <table border="1" id="promoveazaTable" style="display:none;">
        <tr>
            <th>Cod Promoveaza</th>
            <th>Cod Student</th>
            <th>Cod Examen</th>
            <th>Nota</th>
            <th>Șterge</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result_promoveaza)) {
            echo "<tr>";
            echo "<td>" . $row['cod_promoveaza'] . "</td>";
            echo "<td>" . $row['cod_student'] . "</td>";
            echo "<td>" . $row['cod_examen'] . "</td>";
            echo "<td>" . $row['nota'] . "</td>";
            echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_promoveaza_sters' value='" . $row['cod_promoveaza'] . "'>
                        <input type='submit' name='sterge_promoveaza' value='Șterge'>
                    </form>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>
</div>
<div class="form">
    <button onclick="toggleTable('salaOptions')">Administrare Sali</button>
    <div id="salaOptions" style="display:none;">
        <button onclick="toggleTable('saliTable')">Afișează Sali</button>
        <button onclick="toggleTable('formularadaugare')">Adaugă Sală</button>
    </div>

    <div id="formularadaugare" style="display:none;">
        <h2>Adaugă Sală</h2>
        <form method="post" action="">
            Cod Sală: <input type="number" name="cod_sala" required>
            Denumire Sală: <input type="text" name="denumire_sala" required>
            Locație Sală: <input type="text" name="locatie_sala" required>
            Capacitate Sală: <input type="number" name="capacitate_sala" required>
            <input type="submit" name="adauga_sala" value="Adaugă Sală">
        </form>
    </div>

    <table border="1" id="saliTable" style="display:none;">
        <tr>
            <th>Cod Sală</th>
            <th>Denumire Sală</th>
            <th>Locație Sală</th>
            <th>Capacitate Sală</th>
            <th>Șterge</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result_sali)) {
            echo "<tr>";
            echo "<td>" . $row['cod_sala'] . "</td>";
            echo "<td>" . $row['denumire'] . "</td>";
            echo "<td>" . $row['locatie'] . "</td>";
            echo "<td>" . $row['capacitate'] . "</td>";
            echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_sala_stearsa' value='" . $row['cod_sala'] . "'>
                        <input type='submit' name='sterge_sala' value='Șterge'>
                    </form>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>
</div>


<a class="logout-button" href="logout.php">Logout</a>
    </div>
</body>
</html>

<?php
mysqli_close($con);
?>
