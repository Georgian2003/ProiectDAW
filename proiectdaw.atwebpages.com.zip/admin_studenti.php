<?php
include("db.php");
if (isset($_POST['sterge_student'])) {
    $id_student_sters = $_POST['id_student_sters'];

    if (!empty($id_student_sters) && is_numeric($id_student_sters)) {
        $query_sterge_student = "DELETE FROM student WHERE cod_student = $id_student_sters";
        mysqli_query($con, $query_sterge_student);
    }
}

$query_studenti = "SELECT * FROM student";
$result_studenti = mysqli_query($con, $query_studenti);

if (isset($_POST['actualizare_student'])) {
  $id_student_actualizat = $_POST['id_student_actualizat'];

  // Verifică dacă cheia 'telefon_actualizat' există în $_POST
  $telefon_actualizat = isset($_POST['telefon_actualizat']) ? $_POST['telefon_actualizat'] : '';

  // Verifică dacă numărul de telefon are 10 cifre
  if (strlen($telefon_actualizat) === 10) {

      // Verifică dacă ID-ul este valid și actualizează baza de date
      if (!empty($id_student_actualizat) && is_numeric($id_student_actualizat)) {
          $query_actualizare_student = "UPDATE student SET telefon = '$telefon_actualizat' WHERE cod_student = $id_student_actualizat";
          mysqli_query($con, $query_actualizare_student);
      }
  } else {
      // Dacă numărul de telefon nu are 10 cifre, poți gestiona aici ce dorești să faci
      echo "Numărul de telefon nu a fost actualizat deoarece nu ai introdus un nr de telefon valid";
  }
}


$query_studenti = "SELECT * FROM student";
$result_studenti = mysqli_query($con, $query_studenti);
?>

<!DOCTYPE html>
<html lang="ro">
<head>
<style>
   body {
    margin: 0;
    padding: 0;
    font-family: 'Oswald', sans-serif;
    background-image: url('poza3.jpg'); /* Adaugă imaginea de fundal */
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
  }
  
  .container {
    text-align: center;
    background-color: #ffd900b0;
    padding: 20px;
    margin: auto; /* Adaugă această linie pentru a centra containerul */
    margin-top: 100px; /* Ajustează distanța de la partea de sus a paginii */
  }
  
  ul {
    list-style: none;
    margin: 0;
    padding: 0;
  }
  
  a {
    text-decoration: none;
    color: #D2B48C;
  }
  
  /* Header Styles */
  header {
    background-color: transparent;
    padding: 20px;
    text-align: center;
  }
  
  h1 {
    color: #DEB887;
    font-family: 'Great Vibes', cursive;
    font-size: 36px;
    margin: 0;
  }
  
  /* Navigation Styles */
  nav {
    text-align: center;
  }
  
  nav ul {
    display: flex;
    justify-content: center;
  }
  
  nav li {
    margin: 0 15px;
    position: relative;
  }
  
  nav a {
    font-size: 18px;
    text-transform: uppercase;
    color: #D2B48C;
    padding: 15px;
    display: inline-block;
  }
  
  /* Dropdown Styles */
  nav ul ul {
    display: none;
    position: absolute;
    background-color: #36454F;
    border: 1px solid #D2B48C;
    padding: 10px;
  }
  
  nav li:hover > ul {
    display: grid;
  }
  
  nav ul ul li {
    display: block;
    color: #D2B48C;
  }
  
  /* Form Container Styles */
 .form-container {
  margin: 20px;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.form-container h2 {
  color: #36454F;
}

.form-container label {
  display: block;
  margin-top: 10px;
  color: #36454F;
}

.form-container input {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
  margin-bottom: 10px;
  box-sizing: border-box;
}

.form-container button {
  background-color: #36454F;
  color: #fff;
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
  
  label {
    font-weight: bold;
    width: 120px;
    margin-left: 10px;
  }
  
  input,
  textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s ease-in-out;
  }
  
  input:focus,
  textarea:focus {
    border-color: #D2B48C;
  }
  
  .button-container {
    display: flex;
    flex-direction: column; /* Modificare pentru a aranja butoanele pe o coloană */
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  
  button {
    width: 300px; /* Ajustează lățimea butoanelor după preferințe */
    height: 70px; /* Ajustează înălțimea butoanelor după preferințe */
    margin: 10px;
    background-color: #D2B48C;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  
  button:hover {
    background-color: #A88F61;
  }
  
  /* Buton de logout */
  a.logout-button {
    display: block;
    width: 150px; /* Ajustează dimensiunea dorită pentru butonul de logout */
    padding: 15px; /* Ajustează dimensiunea dorită pentru butonul de logout */
    background-color: #D2B48C;
    color: #fff;
    border: none;
    border-radius: 5px;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  
  a.logout-button:hover {
    background-color: #A88F61;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #36454F;
    border: 1px solid #D2B48C;
    padding: 10px;
    z-index: 1;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
  .dropdown-content a {
    color: #D2B48C;
  }
  
  .dropdown-content a:hover {
    background-color: #A88F61;
  }
  /* Tabel Styles */
  table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 20px;
  }
  
  th, td {
    border: 1px solid #D2B48C;
    padding: 8px;
    text-align: left;
    font-size: 16px;
  }
  
  th {
    background-color: #36454F;
    color: #fff;
  }
  
  td {
    background-color: #D2B48C; /* Culoarea de fundal pentru celulele din tabel */
    color: #36454F; /* Culoarea textului pentru contrast */
  }
  
  /* Hover Effect on Rows */
  tr:hover {
    background-color: #D2B48C;
    color: #fff;
  }
  
  /* Button Styles within Table */
  table form {
    display: flex;
    justify-content: space-around;
    align-items: center;
  }
  
  table form input[type="submit"] {
    width: auto;
    background-color: #A88F61;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    padding: 5px 10px;
  }
  
  table form input[type="submit"]:hover {
    background-color: #856C4E;
  }
  #formularAdaugare {
    margin-top: 20px;
    border-radius: 5px;
    background-color: #e6f7ec; /* Culoarea de fundal a formularului */
}

#formularAdaugare input {
    margin-bottom: 10px;
    width: 200px;
    box-sizing: border-box;
}

#formularAdaugare input[type="submit"] {
    background-color: #4caf50; /* Culoarea butonului */
    color: white;
    cursor: pointer;
}

#formularAdaugare input[type="submit"]:hover {
    background-color: #45a049; /* Culoarea butonului la hover */
}
  
</style>
    <meta charset="utf-8">
    <title>Dashboard - Admin Secții</title>
    <link rel="stylesheet" type="text/css" href="numele-fisierului-tau.css"> <!-- Adaugă numele fișierului CSS aici -->
    <script>
        function toggleTable(id) {
            var table = document.getElementById(id);
            table.style.display = (table.style.display === 'none') ? '' : 'none';
        }
    </script>
</head>
<body>
<header>
    <nav id="navigation">
        <ul>
            <li><a href="index_admin.php">Acasă</a></li>
            <li class="dropdown">
                <a href="admin_profesori.php" onclick="toggleDropdown()">Profesori</a>
                <div class="dropdown-content" id="profDropdown">
                    <a href="contracte_profesori.php">Contracte</a>
                    <a href="cursuri_profesori.php">Cursuri</a>
                </div>
            </li>
            <li><a href="admin_studenti.php">Studenți</a></li>
            <li><a href="administrare.php">Administrare</a></li>
        </ul>
    </nav>
</header>
<div class="button-container">
    <div class="form">
        <div id="contractOptions">
            <button onclick="toggleTable('profesoriTable')">Afișează Studenti</button>
            <button onclick="window.location.href='register_student_admin.php'">Adaugă Student</button>
        </div>

        <table border="1" id="profesoriTable" style="display:none;">
            <tr>
                <th>Cod Student</th>
                <th>Nume</th>
                <th>Prenume</th>
                <th>Data Nasterii</th>
                <th>Sex</th>
                <th>Nationalitate</th>
                <th>Telefon</th>
                <th>Email</th>
                <th>Cod Grupa</th>
                <th>Șterge</th>
                <th>Actualizează</th>
            </tr>

            <?php
            while ($row = mysqli_fetch_assoc($result_studenti)) {
                echo "<tr>";
                echo "<td>".$row['cod_student']."</td>";
                echo "<td>".$row['nume']."</td>";
                echo "<td>".$row['prenume']."</td>";
                echo "<td>".$row['data_nasterii']."</td>";
                echo "<td>".$row['sex']."</td>";
                echo "<td>".$row['nationalitate']."</td>";
                echo "<td>".$row['telefon']."</td>";
                echo "<td>".$row['mail']."</td>";
                echo "<td>".$row['cod_grupa']."</td>";
                echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_student_sters' value='" . $row['cod_student'] . "'>
                        <input type='submit' name='sterge_student' value='Șterge'>
                    </form>
                </td>";
                echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_student_actualizat' value='" . $row['cod_student'] . "'>";

                // Adaugă câmpul de actualizare pentru telefon
                echo "<input type='text' name='telefon_actualizat' placeholder='Telefon actualizat' value='" . $row['telefon'] . "'>";


                echo "<input type='submit' name='actualizare_student' value='Actualizează'>
                    </form>
                </td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
    <div class="logout-container">
        <a class="logout-button" href="logout.php">Logout</a>
    </div>
</div>
</body>
</html>

<?php
mysqli_close($con);
?>
