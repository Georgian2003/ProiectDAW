<?php
include("db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['adauga_curs'])) {
        $cod_curs = $_POST['cod_curs'];
        $cod_profesor = $_POST['cod_profesor'];
        $cod_grupa = $_POST['cod_grupa'];
        $cod_sala = $_POST['cod_sala'];
        $cod_materie = $_POST['cod_materie'];
        $durata = $_POST['durata'];

        // Validate numeric fields
        if (
            is_numeric($cod_curs) && is_numeric($cod_profesor) &&
            is_numeric($cod_grupa) && is_numeric($cod_sala) &&
            is_numeric($cod_materie) && is_numeric($durata)
        ) {
            $query_adauga_curs = "INSERT INTO curs (cod_curs, cod_profesor, cod_grupa, cod_sala, cod_materie, durata) VALUES ('$cod_curs', '$cod_profesor', '$cod_grupa', '$cod_sala', '$cod_materie', '$durata')";
            mysqli_query($con, $query_adauga_curs);
        } else {
            echo "Format incorect pentru cod_curs, cod_profesor, cod_grupa, cod_sala, cod_materie sau durata. Toate valorile trebuie să fie numerice.";
        }
    }

    if (isset($_POST['sterge_curs'])) {
        $id_curs_sters = $_POST['id_curs_sters'];

        if (!empty($id_curs_sters) && is_numeric($id_curs_sters)) {
            $query_sterge_curs = "DELETE FROM curs WHERE cod_curs = $id_curs_sters";
            mysqli_query($con, $query_sterge_curs);
        }
    }
}

$query_cursuri = "SELECT * FROM curs";
$result_cursuri = mysqli_query($con, $query_cursuri);

$query_profesori = "SELECT * FROM profesor";
$result_profesori = mysqli_query($con, $query_profesori);
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8">
    <title>Dashboard - Admin Secții</title>
    <script>
        function toggleTable(id) {
            var table = document.getElementById(id);
            table.style.display = (table.style.display === 'none') ? '' : 'none';
        }
    </script>
</head>
<style>
   body {
    margin: 0;
    padding: 0;
    font-family: 'Oswald', sans-serif;
    background-image: url('poza.jpg'); /* Adaugă imaginea de fundal */
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
  }
  body::before {
     content: '';
     position: fixed;
     top: 0;
     left: 0;
     width: 100%;
     height: 100%;
     z-index: -1;
     background-image: url('poza2.jpg');
     background-size: cover;
     background-position: center;
     background-attachment: fixed;
     opacity: 0.8;
   }
  
  .container {
    text-align: center;
    background-color: #ffd900b0;
    padding: 20px;
    margin: auto; /* Adaugă această linie pentru a centra containerul */
    margin-top: 100px; /* Ajustează distanța de la partea de sus a paginii */
  }
  
  ul {
    list-style: none;
    margin: 0;
    padding: 0;
  }
  
  a {
    text-decoration: none;
    color: #D2B48C;
  }
  
  /* Header Styles */
  header {
    background-color: transparent;
    padding: 20px;
    text-align: center;
  }
  
  h1 {
    color: #DEB887;
    font-family: 'Great Vibes', cursive;
    font-size: 36px;
    margin: 0;
  }
  
  /* Navigation Styles */
  nav {
    text-align: center;
  }
  
  nav ul {
    display: flex;
    justify-content: center;
  }
  
  nav li {
    margin: 0 15px;
    position: relative;
  }
  
  nav a {
    font-size: 18px;
    text-transform: uppercase;
    color: #D2B48C;
    padding: 15px;
    display: inline-block;
  }
  
  /* Dropdown Styles */
  nav ul ul {
    display: none;
    position: absolute;
    background-color: #36454F;
    border: 1px solid #D2B48C;
    padding: 10px;
  }
  
  nav li:hover > ul {
    display: grid;
  }
  
  nav ul ul li {
    display: block;
    color: #D2B48C;
  }
  
  /* Form Container Styles */
 .form-container {
  margin: 20px;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.form-container h2 {
  color: #36454F;
}

.form-container label {
  display: block;
  margin-top: 10px;
  color: #36454F;
}

.form-container input {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
  margin-bottom: 10px;
  box-sizing: border-box;
}

.form-container button {
  background-color: #36454F;
  color: #fff;
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
  
  label {
    font-weight: bold;
    width: 120px;
    margin-left: 10px;
  }
  
  input,
  textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s ease-in-out;
  }
  
  input:focus,
  textarea:focus {
    border-color: #D2B48C;
  }
  
  .button-container {
    display: flex;
    flex-direction: column; /* Modificare pentru a aranja butoanele pe o coloană */
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  
  button {
    width: 300px; /* Ajustează lățimea butoanelor după preferințe */
    height: 70px; /* Ajustează înălțimea butoanelor după preferințe */
    margin: 10px;
    background-color: #D2B48C;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  
  button:hover {
    background-color: #A88F61;
  }
  
  /* Buton de logout */
  a.logout-button {
    display: block;
    width: 150px; /* Ajustează dimensiunea dorită pentru butonul de logout */
    padding: 15px; /* Ajustează dimensiunea dorită pentru butonul de logout */
    background-color: #D2B48C;
    color: #fff;
    border: none;
    border-radius: 5px;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  
  a.logout-button:hover {
    background-color: #A88F61;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #36454F;
    border: 1px solid #D2B48C;
    padding: 10px;
    z-index: 1;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
  .dropdown-content a {
    color: #D2B48C;
  }
  
  .dropdown-content a:hover {
    background-color: #A88F61;
  }
  /* Tabel Styles */
  table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 20px;
  }
  
  th, td {
    border: 1px solid #D2B48C;
    padding: 8px;
    text-align: left;
    font-size: 16px;
  }
  
  th {
    background-color: #36454F;
    color: #fff;
  }
  
  td {
    background-color: #D2B48C; /* Culoarea de fundal pentru celulele din tabel */
    color: #36454F; /* Culoarea textului pentru contrast */
  }
  
  /* Hover Effect on Rows */
  tr:hover {
    background-color: #D2B48C;
    color: #fff;
  }
  
  /* Button Styles within Table */
  table form {
    display: flex;
    justify-content: space-around;
    align-items: center;
  }
  
  table form input[type="submit"] {
    width: auto;
    background-color: #A88F61;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    padding: 5px 10px;
  }
  
  table form input[type="submit"]:hover {
    background-color: #856C4E;
  }
  #formularAdaugare {
    margin-top: 20px;
    border-radius: 5px;
    background-color: #e6f7ec; /* Culoarea de fundal a formularului */
}

#formularAdaugare input {
    margin-bottom: 10px;
    width: 200px;
    box-sizing: border-box;
}

#formularAdaugare input[type="submit"] {
    background-color: #4caf50; /* Culoarea butonului */
    color: white;
    cursor: pointer;
}

#formularAdaugare input[type="submit"]:hover {
    background-color: #45a049; /* Culoarea butonului la hover */
}
  
</style>
<body>
<header>
<nav id="navigation">
        <ul>
            <li><a href="index_admin.php">Acasă</a></li>
            <li class="dropdown">
                <a href="admin_profesori.php" onclick="toggleDropdown()">Profesori</a>
                <div class="dropdown-content" id="profDropdown">
                    <a href="contracte_profesori.php">Contracte</a>
                    <a href="cursuri_profesori.php">Cursuri</a>
                </div>
            </li>
            <li><a href="admin_studenti.php">Studenți</a></li>
            <li><a href="administrare.php">Administrare</a></li>
        </ul>
    </nav>
</header>
<div class="button-container">
    <div class="form">
        <div id="contractOptions">
            <button onclick="toggleTable('cursuriTable')">Afișează Cursuri</button>
            <button onclick="toggleTable('cursForm')">Adaugă Curs</button>
        </div>

        <div id="formularAdaugare">
        <div id="cursForm" style="display:none;">
    <h2>Adaugă Curs</h2>
    <form method="post" action="">
        <div style="display: flex; flex-wrap: wrap; gap: 10px;">
            <div style="flex: 1;">
                <label>Cod Curs:</label>
                <input type="number" name="cod_curs" required>
            </div>
            <div style="flex: 1;">
                <label>Cod Profesor:</label>
                <input type="number" name="cod_profesor" required>
            </div>
            <div style="flex: 1;">
                <label>Cod Grupa:</label>
                <input type="number" name="cod_grupa" required>
            </div>
            <div style="flex: 1;">
                <label>Cod Sala:</label>
                <input type="number" name="cod_sala" required>
            </div>
            <div style="flex: 1;">
                <label>Cod Materie:</label>
                <input type="number" name="cod_materie" required>
            </div>
            <div style="flex: 1;">
                <label>Durata:</label>
                <input type="number" name="durata" required>
            </div>
        </div>
        <input type="submit" name="adauga_curs" value="Adaugă Curs">
    </form>
</div>
        </div>

        <table border="1" id="cursuriTable" style="display:none;">
            <tr>
                <th>Cod Curs</th>
                <th>Cod Profesor</th>
                <th>Cod Grupa</th>
                <th>Cod Sala</th>
                <th>Cod Materie</th>
                <th>Durata</th>
                <th>Șterge</th>
            </tr>

            <?php
            while ($row = mysqli_fetch_assoc($result_cursuri)) {
                echo "<tr>";
                echo "<td>" . $row['cod_curs'] . "</td>";
                echo "<td>" . $row['cod_profesor'] . "</td>";
                echo "<td>" . $row['cod_grupa'] . "</td>";
                echo "<td>" . $row['cod_sala'] . "</td>";
                echo "<td>" . $row['cod_materie'] . "</td>";
                echo "<td>" . $row['durata'] . "</td>";
                echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_curs_sters' value='" . $row['cod_curs'] . "'>
                        <input type='submit' name='sterge_curs' value='Șterge'>
                    </form>
                </td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
    <div class="logout-container">
        <a class="logout-button" href="logout.php">Logout</a>
    </div>
</div>

</body>
</html>

<?php
mysqli_close($con);
?>
