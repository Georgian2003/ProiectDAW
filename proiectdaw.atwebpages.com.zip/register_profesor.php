<?php
ob_start();
session_start();
require('db.php');

if (isset($_POST['submit'])) {
    // Verificăm dacă există datele necesare în $_POST pentru profesor
    if (isset($_POST['nume'], $_POST['prenume'], $_POST['telefon'], $_POST['mail'], $_POST['parola'])) {
        $nume = mysqli_real_escape_string($con, $_POST['nume']);
        $prenume = mysqli_real_escape_string($con, $_POST['prenume']);
        $telefon = mysqli_real_escape_string($con, $_POST['telefon']);
        $mail = mysqli_real_escape_string($con, $_POST['mail']);
        $parola = password_hash(mysqli_real_escape_string($con, $_POST['parola']), PASSWORD_DEFAULT);

        // Verificăm dacă profesorul există în tabela profesor
        $verifica_utilizator_query = "SELECT * FROM profesor WHERE nume='$nume' and prenume='$prenume' and mail='$mail' and parola='$parola'";
        $verifica_utilizator_result = mysqli_query($con, $verifica_utilizator_query);

        if (mysqli_num_rows($verifica_utilizator_result) == 0) {
            $query = "SELECT MAX(cod_profesor) AS max_index FROM profesor";
            $result = mysqli_query($con, $query);

            // Verificăm dacă interogarea a avut succes
            if ($result) {
                $row = mysqli_fetch_assoc($result);
                $maxIndex = $row['max_index'];
            }

            if (strlen($telefon) != 10 || !ctype_digit($telefon)) {
                // Telefonul nu are 10 cifre sau conține caractere nepermise
                die("Numărul de telefon trebuie să conțină 10 cifre.");
            }

            if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                // Adresa de email nu este validă
                die("Adresa de email nu este validă.");
            }

            // Adăugăm profesorul în tabela profesor
            $insert_profesor_query = "INSERT INTO profesor (cod_profesor, nume, prenume, telefon, mail, parola) VALUES ($maxIndex + 1, '$nume', '$prenume', '$telefon', '$mail','$parola')";
            mysqli_query($con, $insert_profesor_query) or die(mysqli_error($con));

            echo "<div class='form'>
            <h3>Înregistrarea a fost realizată cu succes.</h3>
            <br/>Click here to <a href='admin_profesori.php'>Pagina Admin</a></div>";
        } else {
            // Utilizatorul există deja, afișăm un mesaj de eroare
            echo "<div class='form'>
            <h3>Profesorul există deja.</h3>
            </div>";
        }
    }
} else {
    // Formularul de înregistrare pentru profesor
    ?>
    <style>body {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
        background-color:#2B65EC
    }
    body::before {
     content: '';
     position: fixed;
     top: 0;
     left: 0;
     width: 100%;
     height: 100%;
     z-index: -1;
     background-image: url('poza.jpg');
     background-size: cover;
     background-position: center;
     background-attachment: fixed;
     opacity: 0.6;
   }
    
    .form {
        width: 300px; /* Ajustați lățimea formularului după preferințe */
        padding: 20px;
        border: 1px solid #FF6347; /* Contur */
        border-radius: 5px; /* Colțuri rotunjite */
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Umbră sub formular */
        background-color:#FF6347;
    }
    
    .form h1 {
        text-align: center;
        color:#FFDEAD;
    }
    
    .form input {
        width: 100%;
        margin-bottom: 10px;
        padding: 8px;
        box-sizing: border-box;
    }
    
    .form input[type="submit"] {
        background-color: #4caf50; /* Culoare de fundal pentru butonul de submit */
        color: white;
        cursor: pointer;
    }
    
    .form input[type="submit"]:hover {
        background-color: #45a049; /* Culoare de fundal pentru butonul de submit la hover */
    }
</style>    
    <div class="form">
        <h1>Adaugă Profesor</h1>
        <form action="" method="post" name="register">
            <input type="text" name="nume" placeholder="Nume" required /> </br>
            <input type="text" name="prenume" placeholder="Prenume" required /> </br>
            <input type="text" name="telefon" placeholder="Telefon" required /> </br>
            <input type="email" name="mail" placeholder="Email" required /> </br>
            <input type="password" name="parola" placeholder="Parola" required /> </br>
            <input name="submit" type="submit" value="Adaugă Profesor" />
        </form>
    </div>
    <?php
}
ob_end_flush();
?>
