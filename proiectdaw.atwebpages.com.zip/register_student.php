<?php
ob_start();
session_start();
require('db.php');

function redirectTo($page) {
    header("Location: $page");
    exit();
}

if (isset($_POST['submit'])) {
    if (
        isset($_POST['nume'], $_POST['prenume'], $_POST['data_nasterii'], $_POST['sex'], $_POST['nationalitate'], $_POST['telefon'], $_POST['mail'], $_POST['cod_grupa'], $_POST['parola'], $_POST['captcha'])
    ) {
        $nume = mysqli_real_escape_string($con, $_POST['nume']);
        $prenume = mysqli_real_escape_string($con, $_POST['prenume']);
        $data_nasterii = mysqli_real_escape_string($con, $_POST['data_nasterii']);
        $sex = mysqli_real_escape_string($con, $_POST['sex']);
        $nationalitate = mysqli_real_escape_string($con, $_POST['nationalitate']);
        $telefon = mysqli_real_escape_string($con, $_POST['telefon']);
        $mail = mysqli_real_escape_string($con, $_POST['mail']);
        $cod_grupa = mysqli_real_escape_string($con, $_POST['cod_grupa']);
        $parola = password_hash(mysqli_real_escape_string($con, $_POST['parola']), PASSWORD_DEFAULT);

        // Verify the CAPTCHA
        $enteredCaptcha = mysqli_real_escape_string($con, $_POST['captcha']);
        if (!is_numeric($enteredCaptcha) || $enteredCaptcha != $_SESSION['captcha_result']) {
            die("<div class='form'>
                <h3>Răspunsul la operația matematică este incorect.</h3>
                </div>");
        }

        $verifica_utilizator_query = "SELECT * FROM student WHERE nume='$nume' and prenume='$prenume' and mail='$mail'";
        $verifica_utilizator_result = mysqli_query($con, $verifica_utilizator_query);

        if (mysqli_num_rows($verifica_utilizator_result) == 0) {
            $query = "SELECT MAX(cod_student) AS max_index FROM student";
            $result = mysqli_query($con, $query);

            if ($result) {
                $row = mysqli_fetch_assoc($result);
                $maxIndex = $row['max_index'];
            }

            if (strlen($telefon) != 10 || !ctype_digit($telefon)) {
                die("Numărul de telefon trebuie să conțină 10 cifre.");
            }

            if (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
                die("Adresa de email nu este validă.");
            }

            $insert_student_query = "INSERT INTO student (cod_student, nume, prenume, data_nasterii, sex, nationalitate, telefon, mail, cod_grupa, parola) VALUES ($maxIndex + 1, '$nume', '$prenume', '$data_nasterii', '$sex', '$nationalitate', '$telefon', '$mail', '$cod_grupa', '$parola')";
            mysqli_query($con, $insert_student_query) or die(mysqli_error($con));
                 redirectTo("profesor_studenti.php");
        } else {
            echo "<div class='form'>
            <h3>Studentul există deja.</h3>
            </div>";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
<style>
body {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
        background-color:#2B65EC
    }
    body::before {
     content: '';
     position: fixed;
     top: 0;
     left: 0;
     width: 100%;
     height: 100%;
     z-index: -1;
     background-image: url('poza.jpg');
     background-size: cover;
     background-position: center;
     background-attachment: fixed;
     opacity: 0.6;
   }
    
    .form {
        width: 300px; /* Ajustați lățimea formularului după preferințe */
        padding: 20px;
        border: 1px solid #FF6347; /* Contur */
        border-radius: 5px; /* Colțuri rotunjite */
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Umbră sub formular */
        background-color:#FF6347;
    }
    
    .form h1 {
        text-align: center;
        color:#FFDEAD;
    }
    
    .form input {
        width: 100%;
        margin-bottom: 10px;
        padding: 8px;
        box-sizing: border-box;
    }
    
    .form input[type="submit"] {
        background-color: #4caf50; /* Culoare de fundal pentru butonul de submit */
        color: white;
        cursor: pointer;
    }
    
    .form input[type="submit"]:hover {
        background-color: #45a049; /* Culoare de fundal pentru butonul de submit la hover */
    }
    </style>
</head>

<body>
    <div id="formularAdaugare" class="form">
        <form method="post" action="">
            <label>Nume:</label>
            <input type="text" name="nume" required>

            <label>Prenume:</label>
            <input type="text" name="prenume" required>

            <label>Data Nasterii:</label>
            <input type="date" name="data_nasterii" required>

            <label>Sex:</label>
            <input type="text" name="sex" required>

            <label>Nationalitate:</label>
            <input type="text" name="nationalitate" required>

            <label>Telefon:</label>
            <input type="tel" name="telefon" pattern="[0-9]{10}" required>

            <label>Email:</label>
            <input type="email" name="mail" pattern=".+@gmail.com" required>

        <label>Cod Grupa:</label>
        <input type="text" name="cod_grupa" required>

        <label>Parola:</label>
        <input type="password" name="parola" required>

        <!-- CAPTCHA -->
        <?php
        $num1 = rand(1, 10);
        $num2 = rand(1, 10);
        $_SESSION['captcha_result'] = $num1 + $num2;

        echo "<label class='captcha-label'>Calculează $num1 + $num2:</label>";
        echo "<input type='text' name='captcha' required>";
        ?>
                 <div class="button-container">
      <a href="logout.php" class="logout-button">Logout</a>
    </div>

        <input type="submit" name="submit" value="Submit">
    </form>
</div>
</body>
</html>
<?php
ob_end_flush();
?>