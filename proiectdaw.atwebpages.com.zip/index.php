<?php
// Include the database connection
require_once('db.php');

// Începe sesiunea
session_start();

if (isset($_POST['username'], $_POST['password'], $_POST['user_type']) and $_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $user_type = mysqli_real_escape_string($con, $_POST['user_type']);

    if ($user_type === 'profesor') {
        // Verificare profesor
        $profesor_query = "SELECT * FROM `profesor` WHERE mail='$username'";
        $profesor_result = mysqli_query($con, $profesor_query) or die(mysqli_error($con));
        $profesor_row = mysqli_fetch_assoc($profesor_result);

        if ($profesor_row && password_verify($password, $profesor_row['parola'])) {
            // Utilizatorul este profesor
            $_SESSION['username'] = $username;
            $_SESSION['rol'] = 'profesor';  // Setează rolul pentru profesor
            header("Location: index_profesor.php"); // Schimbă numele paginii pentru profesori
            exit();
        } 
    } elseif ($user_type === 'student') {
        // Verificare student
        $student_query = "SELECT * FROM `student` WHERE mail='$username'";
        $student_result = mysqli_query($con, $student_query) or die(mysqli_error($con));
        $student_row = mysqli_fetch_assoc($student_result);

        if ($student_row && password_verify($password, $student_row['parola'])) {
            // Utilizatorul este student
            $_SESSION['username'] = $username;
            $_SESSION['rol'] = 'student';  // Setează rolul pentru student
            header("Location: index_student.php");
            exit();
        }
    } elseif ($user_type === 'admin') {
        // Verificare admin
        $admin_query = "SELECT * FROM `profesor` WHERE mail='$username' AND nume='admin'";
        $admin_result = mysqli_query($con, $admin_query) or die(mysqli_error($con));
        $admin_row = mysqli_fetch_assoc($admin_result);

        if ($admin_row && password_verify($password, $admin_row['parola'])) {
            // Utilizatorul este admin
            $_SESSION['username'] = $username;
            $_SESSION['rol'] = 'admin';  // Setează rolul pentru admin
            header("Location: index_admin.php");
            exit();
        } 
}
}
?>
<style>
body {
    display: flex;
    justify-content: center;
    font-family: 'Oswald', sans-serif;
    background-image: url('poza.jpg'); /* Adaugă imaginea de fundal */
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    align-items: center;
    height: 100vh;
    margin: 0;
}
.form {
    width: 400px;
    padding: 20px;
    background-color: #f4f4f4;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.form h1 {
    text-align: center;
}

.form form {
    display: flex;
    flex-direction: column;
}

.form input,
.form select {
    margin-bottom: 10px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.form input[type="submit"] {
    background-color: #4caf50;
    color: white;
    cursor: pointer;
}

.form input[type="submit"]:hover {
    background-color: #45a049;
}
</style>
<div class="form">
    <h1>Login</h1>
    <form action="" method="post" name="login">
        <input type="text" name="username" placeholder="Username" required />
        <input type="password" name="password" placeholder="Password" required />
        <select name="user_type">
            <option value="admin">Admin</option>
            <option value="profesor">Profesor</option>
            <option value="student">Student</option>
        </select>
        <input name="submit" type="submit" value="Login" />
    </form>
</div>
