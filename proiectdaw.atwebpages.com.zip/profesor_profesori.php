<?php
include("db.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['adauga_curs'])) {
        $cod_curs = $_POST['cod_curs'];
        $cod_profesor = $_POST['cod_profesor'];
        $cod_grupa = $_POST['cod_grupa'];
        $cod_sala = $_POST['cod_sala'];
        $cod_materie = $_POST['cod_materie'];
        $durata = $_POST['durata'];

        // Validate numeric fields
        if (
            is_numeric($cod_curs) && is_numeric($cod_profesor) &&
            is_numeric($cod_grupa) && is_numeric($cod_sala) &&
            is_numeric($cod_materie) && is_numeric($durata)
        ) {
            $query_adauga_curs = "INSERT INTO curs (cod_curs, cod_profesor, cod_grupa, cod_sala, cod_materie, durata) VALUES ('$cod_curs', '$cod_profesor', '$cod_grupa', '$cod_sala', '$cod_materie', '$durata')";
            mysqli_query($con, $query_adauga_curs);
        } else {
            echo "Format incorect pentru cod_curs, cod_profesor, cod_grupa, cod_sala, cod_materie sau durata. Toate valorile trebuie să fie numerice.";
        }
    }

    if (isset($_POST['sterge_curs'])) {
        $id_curs_sters = $_POST['id_curs_sters'];

        if (!empty($id_curs_sters) && is_numeric($id_curs_sters)) {
            $query_sterge_curs = "DELETE FROM curs WHERE cod_curs = $id_curs_sters";
            mysqli_query($con, $query_sterge_curs);
        }
    }
}

$query_cursuri = "SELECT * FROM curs";
$result_cursuri = mysqli_query($con, $query_cursuri);
?>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adauga_examen'])) {
    $cod_examen = $_POST['cod_examen'];
    $nota_minima = $_POST['nota_minima'];
    $mod_de_sustinere = $_POST['mod_de_sustinere'];
    $cod_materie_examen = $_POST['cod_materie_examen'];

    // Verificare format cod_examen, nota_minima și mod_de_sustinere
    if (is_numeric($cod_examen) && is_numeric($nota_minima) && $nota_minima >= 1 && $nota_minima <= 10 && ctype_alpha($mod_de_sustinere) && is_numeric($cod_materie_examen)) {
        // Continuă cu operația de inserare în baza de date
        $query_adauga_examen = "INSERT INTO examen (cod_examen, nota_minima, mod_de_sustinere, cod_materie) VALUES ('$cod_examen', '$nota_minima', '$mod_de_sustinere', '$cod_materie_examen')";
        mysqli_query($con, $query_adauga_examen);
    } else {
        // Afisează mesaj de eroare sau redirectează către o pagină de eroare
        echo "Format incorect pentru cod_examen, nota_minima, mod_de_sustinere sau cod_materie_examen. Codul examenului, nota minimă trebuie să fie un număr între 1 și 10, modul de susținere să conțină doar litere, iar codul materiei să conțină doar cifre.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sterge_examen'])) {
    $id_examen_sters = $_POST['id_examen_sters'];

    if (!empty($id_examen_sters)) {
        $query_sterge_examen = "DELETE FROM examen WHERE cod_examen = $id_examen_sters";
        mysqli_query($con, $query_sterge_examen);
    }
}

$query_examene = "SELECT * FROM examen";
$result_examene = mysqli_query($con, $query_examene);
?>
<?php
$query_profesori = "SELECT * FROM profesor";
$result_profesori = mysqli_query($con, $query_profesori);
?>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adauga_promoveaza'])) {
    $cod_promoveaza = $_POST['cod_promoveaza'];
    $cod_student_promoveaza = $_POST['cod_student_promoveaza'];
    $cod_examen_promoveaza = $_POST['cod_examen_promoveaza'];
    $nota_promoveaza = $_POST['nota_promoveaza'];

    // Verificare format cod_promoveaza, cod_student_promoveaza, cod_examen_promoveaza și nota_promoveaza
    if (is_numeric($cod_promoveaza) && is_numeric($cod_student_promoveaza) && is_numeric($cod_examen_promoveaza) && is_numeric($nota_promoveaza) && $nota_promoveaza >= 1 && $nota_promoveaza <= 10) {
        // Continuă cu operația de inserare în baza de date
        $query_adauga_promoveaza = "INSERT INTO promoveaza (cod_promoveaza, cod_student, cod_examen, nota) VALUES ('$cod_promoveaza', '$cod_student_promoveaza', '$cod_examen_promoveaza', '$nota_promoveaza')";
        mysqli_query($con, $query_adauga_promoveaza);
    } else {
        // Afisează mesaj de eroare sau redirectează către o pagină de eroare
        echo "Format incorect pentru cod_promoveaza, cod_student_promoveaza, cod_examen_promoveaza sau nota_promoveaza. Codul de promovare, codul studentului și codul examenului trebuie să conțină doar cifre, iar nota să fie un număr între 1 și 10.";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sterge_promoveaza'])) {
    $id_promoveaza_sters = $_POST['id_promoveaza_sters'];

    if (!empty($id_promoveaza_sters)) {
        $query_sterge_promoveaza = "DELETE FROM promoveaza WHERE cod_promoveaza = $id_promoveaza_sters";
        mysqli_query($con, $query_sterge_promoveaza);
    }
}

$query_promoveaza = "SELECT * FROM promoveaza";
$result_promoveaza = mysqli_query($con, $query_promoveaza);
?>
<style>
    body {
    margin: 0;
    padding: 0;
    font-family: 'Oswald', sans-serif;
    background-image: url('poza.jpg'); /* Adaugă imaginea de fundal */
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
  }
  body::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
    background-image: url('poza5.jpg');
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    opacity: 0.6;
  }
  
  .container {
    text-align: center;
    background-color: #ffd900b0;
    padding: 20px;
    margin: auto; /* Adaugă această linie pentru a centra containerul */
    margin-top: 100px; /* Ajustează distanța de la partea de sus a paginii */
  }
  
  ul {
    list-style: none;
    margin: 0;
    padding: 0;
  }
  
  a {
    text-decoration: none;
    color: #D2B48C;
  }
  
  /* Header Styles */
  header {
    background-color: transparent;
    padding: 20px;
    text-align: center;
  }
  
  h1 {
    color: #DEB887;
    font-family: 'Great Vibes', cursive;
    font-size: 36px;
    margin: 0;
  }
  
  /* Navigation Styles */
  nav {
    text-align: center;
  }
  
  nav ul {
    display: flex;
    justify-content: center;
  }
  
  nav li {
    margin: 0 15px;
    position: relative;
  }
  
  nav a {
    font-size: 18px;
    text-transform: uppercase;
    color: #D2B48C;
    padding: 15px;
    display: inline-block;
  }
  
  /* Dropdown Styles */
  nav ul ul {
    display: none;
    position: absolute;
    background-color: #36454F;
    border: 1px solid #D2B48C;
    padding: 10px;
  }
  
  nav li:hover > ul {
    display: grid;
  }
  
  nav ul ul li {
    display: block;
    color: #D2B48C;
  }
  
  /* Form Container Styles */
 .form-container {
  margin: 20px;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.form-container h2 {
  color: #36454F;
}

.form-container label {
  display: block;
  margin-top: 10px;
  color: #36454F;
}

.form-container input {
  width: 100%;
  padding: 8px;
  margin-top: 5px;
  margin-bottom: 10px;
  box-sizing: border-box;
}

.form-container button {
  background-color: #36454F;
  color: #fff;
  padding: 10px 15px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
  
  label {
    font-weight: bold;
    width: 120px;
    margin-left: 10px;
  }
  
  input,
  textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    transition: border-color 0.3s ease-in-out;
  }
  
  input:focus,
  textarea:focus {
    border-color: #D2B48C;
  }
  
  .button-container {
    display: flex;
    flex-direction: column; /* Modificare pentru a aranja butoanele pe o coloană */
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  
  button {
    width: 300px; /* Ajustează lățimea butoanelor după preferințe */
    height: 70px; /* Ajustează înălțimea butoanelor după preferințe */
    margin: 10px;
    background-color: #D2B48C;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  
  button:hover {
    background-color: #A88F61;
  }
  
  /* Buton de logout */
  a.logout-button {
    display: block;
    width: 150px; /* Ajustează dimensiunea dorită pentru butonul de logout */
    padding: 15px; /* Ajustează dimensiunea dorită pentru butonul de logout */
    background-color: #D2B48C;
    color: #fff;
    border: none;
    border-radius: 5px;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    transition: background-color 0.3s ease-in-out;
  }
  
  a.logout-button:hover {
    background-color: #A88F61;
  }
  
  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #36454F;
    border: 1px solid #D2B48C;
    padding: 10px;
    z-index: 1;
  }
  
  .dropdown:hover .dropdown-content {
    display: block;
  }
  
  .dropdown-content a {
    color: #D2B48C;
  }
  
  .dropdown-content a:hover {
    background-color: #A88F61;
  }
  /* Tabel Styles */
  table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 20px;
  }
  
  th, td {
    border: 1px solid #D2B48C;
    padding: 8px;
    text-align: left;
    font-size: 16px;
  }
  
  th {
    background-color: #36454F;
    color: #fff;
  }
  
  td {
    background-color: #D2B48C; /* Culoarea de fundal pentru celulele din tabel */
    color: #36454F; /* Culoarea textului pentru contrast */
  }
  
  /* Hover Effect on Rows */
  tr:hover {
    background-color: #D2B48C;
    color: #fff;
  }
  
  /* Button Styles within Table */
  table form {
    display: flex;
    justify-content: space-around;
    align-items: center;
  }
  
  table form input[type="submit"] {
    width: auto;
    background-color: #A88F61;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    padding: 5px 10px;
  }
  
  table form input[type="submit"]:hover {
    background-color: #856C4E;
  }
  #formularAdaugare {
    margin-top: 20px;
    padding: 15px;
    border: 1px solid #4682B4;
    border-radius: 5px;
    background-color: #e6f7ec; /* Culoarea de fundal a formularului */
}

#formularAdaugare input {
    margin-bottom: 10px;
    padding: 8px;
    width: 200px;
    box-sizing: border-box;
}

#formularAdaugare input[type="submit"] {
    background-color: #4caf50; /* Culoarea butonului */
    color: white;
    cursor: pointer;
}

#formularAdaugare input[type="submit"]:hover {
    background-color: #45a049; /* Culoarea butonului la hover */
}
  
    </style>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="utf-8">
    <title>Dashboard - Profesori</title>
    <script>
        function toggleTable(id) {
            var table = document.getElementById(id);
            table.style.display = (table.style.display === 'none') ? '' : 'none';
        }
    </script>
</head>
<body>
<header>
<nav id="navigation">
  <ul>
    <li><a href="index_profesor.php">Acasă</a></li>
    <li class="dropdown">
  <a href="profesor_profesori.php" onclick="toggleDropdown()">Profesori</a>
  </div>
</li>
    <li><a href="profesor_studenti.php">Studenți</a></li>
  </ul>
</nav>
  </header>
<div class="button-container">    
    <div class="form">
            <button onclick="toggleTable('profesoriTable')">Afișează Profesori</button>
    </div>
<table border="1" id="profesoriTable" style="display:none;">
            <tr>
                <th>Cod Profesor</th>
                <th>Nume</th>
                <th>Prenume</th>
                <th>Telefon</th>
                <th>Email</th>
                <th>Cod Facultate</th>
            </tr>

            <?php
            while ($row = mysqli_fetch_assoc($result_profesori)) {
                echo "<tr>";
                echo "<td>" . $row['cod_profesor'] . "</td>";
                echo "<td>" . $row['nume'] . "</td>";
                echo "<td>" . $row['prenume'] . "</td>";
                echo "<td>" . $row['telefon'] . "</td>";
                echo "<td>" . $row['mail'] . "</td>";
                echo "<td>" . $row['cod_facultate'] . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
        <div class="form">
        <button onclick="toggleTable('cursuriOptions')">Administrare Cursuri</button>
        <div id="cursuriOptions" style="display:none">
            <button onclick="toggleTable('cursuriTable')">Afișează Cursuri</button>
            <button onclick="toggleTable('cursForm')">Adaugă Curs</button>
        </div>
    </div>
        <div id="cursForm" style="display:none;">
             <div id="formularAdaugare">
    <h2>Adaugă Curs</h2>
    <form method="post" action="">
        <div style="display: flex; flex-wrap: wrap; gap: 10px;">
            <div style="flex: 1;">
                <label>Cod Curs:</label>
                <input type="number" name="cod_curs" required>
            </div>
            <div style="flex: 1;">
                <label>Cod Profesor:</label>
                <input type="number" name="cod_profesor" required>
            </div>
            <div style="flex: 1;">
                <label>Cod Grupa:</label>
                <input type="number" name="cod_grupa" required>
            </div>
            <div style="flex: 1;">
                <label>Cod Sala:</label>
                <input type="number" name="cod_sala" required>
            </div>
            <div style="flex: 1;">
                <label>Cod Materie:</label>
                <input type="number" name="cod_materie" required>
            </div>
            <div style="flex: 1;">
                <label>Durata:</label>
                <input type="number" name="durata" required>
            </div>
        </div>
        <input type="submit" name="adauga_curs" value="Adaugă Curs">
    </form>
</div>
        </div>
        <table border="1" id="cursuriTable" style="display:none;">
            <tr>
                <th>Cod Curs</th>
                <th>Cod Profesor</th>
                <th>Cod Grupa</th>
                <th>Cod Sala</th>
                <th>Cod Materie</th>
                <th>Durata</th>
                <th>Șterge</th>
            </tr>

            <?php
            while ($row = mysqli_fetch_assoc($result_cursuri)) {
                echo "<tr>";
                echo "<td>" . $row['cod_curs'] . "</td>";
                echo "<td>" . $row['cod_profesor'] . "</td>";
                echo "<td>" . $row['cod_grupa'] . "</td>";
                echo "<td>" . $row['cod_sala'] . "</td>";
                echo "<td>" . $row['cod_materie'] . "</td>";
                echo "<td>" . $row['durata'] . "</td>";
                echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_curs_sters' value='" . $row['cod_curs'] . "'>
                        <input type='submit' name='sterge_curs' value='Șterge'>
                    </form>
                </td>";
                echo "</tr>";
            }
            ?>
        </table>
        <div class="form">
        <button onclick="toggleTable('examenOptions')">Administrare Examene</button>
        <div id="examenOptions" style="display:none;">
            <button onclick="toggleTable('exameneTable')">Afișează Examene</button>
            <button onclick="toggleTable('examenForm')">Adaugă Examen</button>
        </div>
    </div>
    <div id="examenForm" style="display:none;">
        <form method="post" action="" id="formularadaugare">
        <h2>Adaugă Examen</h2>
            Cod Examen: <input type="number" name="cod_examen" required>
            Nota Minima: <input type="number" name="nota_minima" required>
            Mod de Sustinere: <input type="text" name="mod_de_sustinere" required>
            Cod Materie: <input type="number" name="cod_materie_examen" required>
            <input type="submit" name="adauga_examen" value="Adaugă Examen">
        </form>
    </div>

    <table border="1" id="exameneTable" style="display:none;">
        <tr>
            <th>Cod Examen</th>
            <th>Nota Minima</th>
            <th>Mod de Sustinere</th>
            <th>Cod Materie</th>
            <th>Șterge</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result_examene)) {
            echo "<tr>";
            echo "<td>" . $row['cod_examen'] . "</td>";
            echo "<td>" . $row['nota_minima'] . "</td>";
            echo "<td>" . $row['mod_de_sustinere'] . "</td>";
            echo "<td>" . $row['cod_materie'] . "</td>";
            echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_examen_sters' value='" . $row['cod_examen'] . "'>
                        <input type='submit' name='sterge_examen' value='Șterge'>
                    </form>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>
<div class="form">
        <button onclick="toggleTable('promoveazaOptions')">Administrare Promoveaza</button>
        <div id="promoveazaOptions" style="display:none;">
            <button onclick="toggleTable('promoveazaTable')">Afișează Promoveaza</button>
            <button onclick="toggleTable('promoveazaForm')">Adaugă Promoveaza</button>
        </div>
    </div>
    <div id="promoveazaForm" style="display:none;">
        <form method="post" action="" id="formularadaugare">
        <h2>Adaugă Promoveaza</h2>
            Cod Promoveaza: <input type="number" name="cod_promoveaza" required>
            Cod Student: <input type="number" name="cod_student_promoveaza" required>
            Cod Examen: <input type="number" name="cod_examen_promoveaza" required>
            Nota: <input type="number" name="nota_promoveaza" required>
            <input type="submit" name="adauga_promoveaza" value="Adaugă Promoveaza">
        </form>
    </div>

    <table border="1" id="promoveazaTable" style="display:none;">
        <tr>
            <th>Cod Promoveaza</th>
            <th>Cod Student</th>
            <th>Cod Examen</th>
            <th>Nota</th>
            <th>Șterge</th>
        </tr>

        <?php
        while ($row = mysqli_fetch_assoc($result_promoveaza)) {
            echo "<tr>";
            echo "<td>" . $row['cod_promoveaza'] . "</td>";
            echo "<td>" . $row['cod_student'] . "</td>";
            echo "<td>" . $row['cod_examen'] . "</td>";
            echo "<td>" . $row['nota'] . "</td>";
            echo "<td>
                    <form method='post' action=''>
                        <input type='hidden' name='id_promoveaza_sters' value='" . $row['cod_promoveaza'] . "'>
                        <input type='submit' name='sterge_promoveaza' value='Șterge'>
                    </form>
                  </td>";
            echo "</tr>";
        }
        ?>
    </table>
    <a class="logout-button" href="logout.php">Logout</a>
    </div>
    </div>
</body>
</html>

<?php
mysqli_close($con);
?>
