<?php
include("auth.php");
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="utf-8">
  <title>Dashboard - Admin</title>
  <link rel="stylesheet" href="style1.css">
  <script>
  function toggleTable(id) {
    var table = document.getElementById(id);
    table.style.display = (table.style.display === 'none') ? '' : 'none';
  }

  function toggleDropdown() {
    var dropdownContent = document.getElementById('profDropdown');
    dropdownContent.style.display = (dropdownContent.style.display === 'none') ? 'block' : 'none';
  }
</script>

</head>
<body>
  <header>
    <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
    <nav id="navigation">
  <ul>
    <li><a href="index_admin.php">Acasă</a></li>
    <li class="dropdown">
  <a href="admin_profesori.php" onclick="toggleDropdown()">Profesori</a>
  <div class="dropdown-content" id="profDropdown">
    <a href="contracte_profesori.php">Contracte</a>
    <a href="cursuri_profesori.php">Cursuri</a>
  </div>
</li>
    <li><a href="admin_studenti.php">Studenți</a></li>
  <li>   <a href="administrare.php">Administrare</a></li>
  </ul>
</nav>
  </header>
  <div class="main-content">
    <div class="text-container">
      <div class="text-grid">
      Facultatea de Matematică și Informatică a Universității din București este cea mai bună dintre cele de profil din țară, fiind clasificată în categoria A la domeniile Matematică (locul 3) și Informatică (locul 1).
<p>Oferta curriculară cuprinde 6 programe de studii de licență (din care 1 program la distanță) în 3 domenii (Matematică, Informatică și Calculatoare și tehnologia informației), 12 programe de studii de master (din care 1 program în limba engleză, 1 program interdisciplinar și 1 program cu frecvență redusă) în 2 domenii (Matematică și Informatică), precum și studii doctorale în 2 domenii (Matematică și Informatică).

<p>Facultatea dispune de o bază materială bine dotată, care include bibliotecă, 4 amfiteatre multimedia și alte 15 săli de curs și seminar (din care 8 săli multimedia), 15 laboratoare (din care laboratoare specializate de baze de date, rețele de calculatoare, dezvoltare de software, aplicații mobile, robotică, matematici aplicate și statistică, dar și laboratoare generaliste de informatică).

<p>Studenții facultății beneficiază de burse subvenționate de stat, burse private și burse în străinătate. În timpul studiilor, studenții pot beneficia de burse Erasmus în universități din Italia, Franța, Finlanda, Germania, Suedia etc.

<p>Facultatea colaborează cu instituții guvernamentale și companii din domeniile financiar-bancar, asigurări, tranzacții bursiere, dezvoltare de software, integrare de sisteme informatice, telecomunicații, precum și alte companii mari, cu divizii informatice proprii.

<p>Angajabilitatea în domeniu a absolvenților facultății este foarte mare (peste 90%).
<p>Corpul profesoral al facultății este implicat în proiecte de cercetare naționale și internaționale, membrii săi fiind recompensați cu numeroase premii și distincții (premii pentru articolele publicate, premii pentru activitatea de cercetare, premii ale Academiei Române etc).

<p>Oportunitățile de carieră pentru absolvenții Facultății de Matematică și Informatică sunt numeroase, incluzând: actuar, analist financiar bancar, specialist sistem asigurări, statistician farmacolog, administrator baze de date, administrator rețele de date și de telefonie peste Internet (VoIP), analist software, consultant în informatică, proiectant sisteme informatice, inginer de sistem informatic, specialist IT, manager de proiect informatic, profesor în învățământul preuniversitar, profesor în învățământul universitar / cercetător științific, programator (sisteme enterprise, web și mobile) etc.
      </div>
    </div>

    <div class="button-container">
      <a href="logout.php" class="logout-button">Logout</a>
    </div>
  </div>
</body>
</html>
