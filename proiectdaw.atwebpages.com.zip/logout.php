<?php
session_start();
// Distrugem toate variabilele de sesiune
session_destroy();
// Redirecționăm utilizatorul la pagina de login
header("Location: index.php");
exit();
?>
